from django.apps import AppConfig


class DownloadConfig(AppConfig):
    name = 'download'
