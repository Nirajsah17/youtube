from django.shortcuts import render,redirect
import pafy as pf
# Create your views here.
def sdownload(url):
    video = pf.new(url)
    title = video.title
    author = video.author
    length = video.length
    thumbnail =  video.bigthumb
    stream = video.streams
    list_link = {'title':title,'author':author,'length':length,'thumbnail':thumbnail,'dlink':dlink}
    return list_link
def download(url):
    video = pf.new(url)
    v= video.getbest()   
    return v.download()
    

def playlist(url):
    playlist = pf.get_playlist(url)
    playlist_title = playlist['title']
    thumb = playlist.thumb()
    return playlist_title,thumb
    
    
def index(request):
    if request.method == 'POST':
        url = request.POST.get('url')
        data = sdownload(url)
        return render(request,'index.html',{'data':data})
    else:
        return render(request,'index.html')
        



def playlist_url(request):
    if request.method == 'POST':
        url = request.POST.get('url')
        data = playlist(url)
        return render(request,'playlist.html',{'data': data})
    else:
        return render(request,'playlist.html')
